package bps.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "customerTable")
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "customerId")
	private long customerId;

	/*@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "cardNumber")
	private CardDetails cardDetails;
*/
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "customervendor", joinColumns = { @JoinColumn(name = "customerId") }, inverseJoinColumns = {
			@JoinColumn(name = "vendorType") })
	private List<VendorType> vendorType;

	@Column
	private String customerName;
	@Column
	private String customerAddress;
	@Column
	private String customerContactNumber;
	@Column
	private String customerCountry;
	@Column
	private String customerState;
	@Column
	private String customerMailId;
	@Column
	private String customerIdentificationdocument;
	@Column
	private String customerDocumentDetailNumber;
	@Column
	private Date customerRegistrationDate;
	@Column
	private String customerBalance;
	@Column
	private String cardNumber;
	@Column
	private String cardType;
	@Column
	private String cardValidity;
	@Column
	private String cvv;


	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerContactNumber() {
		return customerContactNumber;
	}

	public void setCustomerContactNumber(String customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}

	public String getCustomerCountry() {
		return customerCountry;
	}

	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}

	public String getCustomerState() {
		return customerState;
	}

	public void setCustomerState(String customerState) {
		this.customerState = customerState;
	}

	public String getCustomerMailId() {
		return customerMailId;
	}

	public void setCustomerMailId(String customerMailId) {
		this.customerMailId = customerMailId;
	}

	public String getCustomerIdentificationdocument() {
		return customerIdentificationdocument;
	}

	public void setCustomerIdentificationdocument(String customerIdentificationdocument) {
		this.customerIdentificationdocument = customerIdentificationdocument;
	}

	public String getCustomerDocumentDetailNumber() {
		return customerDocumentDetailNumber;
	}

	public void setCustomerDocumentDetailNumber(String customerDocumentDetailNumber) {
		this.customerDocumentDetailNumber = customerDocumentDetailNumber;
	}

	public Date getCustomerRegistrationDate() {
		return customerRegistrationDate;
	}

	public void setCustomerRegistrationDate(Date customerRegistrationDate) {
		this.customerRegistrationDate = customerRegistrationDate;
	}

	public String getCustomerBalance() {
		return customerBalance;
	}

	public void setCustomerBalance(String customerBalance) {
		this.customerBalance = customerBalance;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	
	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCardValidity() {
		return cardValidity;
	}

	public void setCardValidity(String cardValidity) {
		this.cardValidity = cardValidity;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public List<VendorType> getVendorType() {
		return vendorType;
	}

	public void setVendorType(List<VendorType> vendorType) {
		this.vendorType = vendorType;
	}

}